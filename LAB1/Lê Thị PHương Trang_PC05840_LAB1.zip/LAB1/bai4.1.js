
////LAB1-Bài 4.1
fetch("https://datausa.io/api/data?drilldowns=Nation&measures=Population")
    .then(function(resource2){
        resource2.json().then(function(entries){
            console.log(entries.data);
            let array = entries.data;
            let html = document.getElementById('Lab1.3')
            let child_html = `<table class="table">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nation</th>
                                    <th scope="col">Year</th>
                                    <th scope="col">Population</th>
                                </tr>
                                </thead>
                                <tbody>`
            array.forEach((element, id) => {
                child_html += ` <tr>
                <td>${id + 1}</td>
                <td>${element.Nation}</td>
                <td>${element.Year}</td>
                <td>${element.Population}</td>
              </tr>`;
            });
            child_html +=   `</tbody>
                            </table>`;
            html.innerHTML = child_html

        })
    });