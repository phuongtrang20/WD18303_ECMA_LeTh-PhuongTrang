
////LAB1-Bài 4.2 
fetch("https://65929f4fbb129707198fe18e.mockapi.io/tinhpv10/students")
    .then(function(resource3){
        resource3.json().then(function(data){
            let html = document.getElementById('Bai4.2')
            let child_html = `<table class="table">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Ảnh đại diện</th>
                                    <th scope="col">Họ và tên</th>
                                    <th scope="col">Ngày tạo</th>
                                </tr>
                                </thead>
                                <tbody>`;
            data.forEach(element => {
                child_html += `<tr>
                <td>${element.id}</td>
                <td><img src="${element.avatar}"</td>
                <td>${element.name}</td>
                <td>${element.createdAt}</td>
              </tr>`
            });
            child_html +=   `</tbody>
                            </table>`;
            html.innerHTML = child_html
        })
    })