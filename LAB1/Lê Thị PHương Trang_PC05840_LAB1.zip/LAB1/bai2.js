////LAB1-Bài 2
let name = 'Phuong Trang';
let age = '19';
let sayHello = () => {
    console.log(`I'm ${name}, ${age}`);
}